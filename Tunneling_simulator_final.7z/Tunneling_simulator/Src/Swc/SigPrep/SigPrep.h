/*
 * SigPrep.h
 *
 *  Created on: Jul 12, 2018
 *      Author: F16438C
 */

#ifndef SWC_SIGPREP_SIGPREP_H_
#define SWC_SIGPREP_SIGPREP_H_

//signals
#define SIGN_DET 256
#define WET_DET 512
#define BEAM_DET 768
#define TUNN_SWITCH 1024
#define TRACK_BAR 1280
#define BEND_LIGHT 1536
#define TRUE 1
#define FALSE 0

typedef enum
{
	LEFT=0,
	STRAIGHT,
	RIGHT,
	OFF
}eTurnStatus;

typedef struct
{
	uint16_t ID;
	uint16_t Data;
} CAN_Info;

typedef struct
{
	_Bool bSignDetect;
	_Bool bWeatherGlare;
	_Bool bBeamStatus;
	_Bool bAutoStatus;
	uint8_t u8TurnStatus;
	uint8_t u8TrackBar;

}System_CANStatus;



#endif /* SWC_SIGPREP_SIGPREP_H_ */
