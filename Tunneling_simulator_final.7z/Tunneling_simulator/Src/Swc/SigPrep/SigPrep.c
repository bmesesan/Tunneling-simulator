/*
 * SigPrep.c
 *
 *  Created on: Jul 12, 2018
 *      Author: F16438C
 */


#include "main.h"
#include "stm32f4xx_hal.h"
#include "stdlib.h"
#include "SigPrep.h"
#include "stm32f4xx_hal_gpio.h"

volatile uint16_t datarx[6] ;
uint16_t StateArray[4];
uint8_t TransmitMailbox = 0;
volatile uint16_t ID;
uint8_t DATA1;
CAN_HandleTypeDef hcan1;
SPI_HandleTypeDef hspi1;
CAN_Info c1;

void Tunneling(uint16_t DistanceArraySensors[]);
void BendLightLeft(SPI_HandleTypeDef hspi1);
void BendLightRight(SPI_HandleTypeDef hspi1);
void StraightRoad(SPI_HandleTypeDef hspi1);
void InitCANStatus(System_CANStatus c2);
void UpdateCANStatus(CAN_Info *c1, System_CANStatus *c2);
CAN_Info CAN_Rx(void);

void InitCANStatus(System_CANStatus c2)
{
	 c2.bSignDetect=FALSE;
	 c2.bWeatherGlare=FALSE;
	 c2.bBeamStatus=FALSE;
	 c2.bAutoStatus=FALSE;
	 c2.u8TurnStatus=1;
	 c2.u8TrackBar=-1;
}

void UpdateCANStatus(CAN_Info *c1, System_CANStatus *c2)
{
		if(c1->ID == SIGN_DET && c1->Data == 1)
		{
			c2->bSignDetect=TRUE;
		}
		if(c1->ID == SIGN_DET && c1->Data == 2)
		{
			c2->bSignDetect=FALSE;
		}
		if(c1->ID == WET_DET && c1->Data == 1)
		{
			c2->bWeatherGlare=TRUE;
		}
		if(c1->ID == WET_DET && c1->Data == 2)
		{
			c2->bWeatherGlare=FALSE;
		}
		if(c1->ID == BEAM_DET && c1->Data == 2)
		{
			c2->bBeamStatus=TRUE;
		}
		if(c1->ID == BEAM_DET && c1->Data == 3)
		{
			c2->bBeamStatus=FALSE;
		}
		if(c1->ID == TUNN_SWITCH && c1->Data == 2)
		{
			c2->bAutoStatus=TRUE;
		}
		if(c1->ID == TUNN_SWITCH && c1->Data == 1)
		{
			c2->bAutoStatus=FALSE;
		}
		if(c1->ID == TRACK_BAR)
		{
			c2->u8TrackBar=c1->Data;
		}
		if(c1->ID == BEND_LIGHT && c1->Data == 0)
		{
			c2->u8TurnStatus=0;
		}
		if(c1->ID == BEND_LIGHT && c1->Data == 1)
		{
			c2->u8TurnStatus=1;
		}
		if(c1->ID == BEND_LIGHT && c1->Data == 2)
		{
			c2->u8TurnStatus=2;
		}

}

CAN_Info verif_msg(volatile uint16_t ID,uint8_t DATA1)
{
	c1.ID = ID;
	c1.Data = (uint16_t)DATA1;

	return (c1);
}

/*
void CAN_Tx(uint32_t ID){

	hcan1.pTxMsg->StdId = ID;
	hcan1.pTxMsg->ExtId= 1;
	hcan1.pTxMsg->RTR = CAN_RTR_DATA;
	hcan1.pTxMsg->IDE = CAN_ID_STD;
	hcan1.pTxMsg->DLC = 1;
	hcan1.pTxMsg->Data[0] = 0x00;

	TransmitMailbox = HAL_CAN_Transmit(&hcan1, 10);
	do
	{
		TransmitMailbox = HAL_CAN_Transmit(&hcan1, 10);

	}
	while (TransmitMailbox == CAN_TXSTATUS_NOMAILBOX);

	HAL_CAN_Transmit(&hcan1, 10);

}
*/
CAN_Info CAN_Rx(void)
{
	if(HAL_CAN_Receive(&hcan1, CAN_FILTER_FIFO0, 10)==HAL_OK)
	{
		 return (verif_msg(hcan1.pRxMsg->StdId,hcan1.pRxMsg->Data[0]));
	}
	else
	{
		return (verif_msg(0,0));
	}
}
