#include "main.h"
#include "stm32f4xx_hal.h"
#include "math.h"
#include "Sense.h"
#include "stdlib.h"

uint16_t give_Distance(uint16_t voltage);
uint16_t give_Voltage(uint16_t adcReading);
uint16_t aproxDistance(uint16_t volt);
void init_distanceArray(void);
void configure_Voltage(uint16_t adcValArray[], uint16_t VoltageArray[]);
void configure_Distance(ADC_HandleTypeDef hadc1, uint16_t adcValArray[], uint16_t DistanceArraySensors[], uint16_t VoltageArray[]);
void Distance_from_all_sensors(ADC_HandleTypeDef hadc1, uint16_t DistanceArraySensors[]);
uint16_t Mean_Value(int pos);
float Standard_Deviation(int pos);
int High_Val(int n);
int Low_Val(int n);
int Give_State(uint16_t n);
void State_config(uint16_t StateArray[], uint16_t DistanceArraySensors[]);
void init_StateArray(uint16_t StateArray[]);
void Value_Filtering(uint16_t DistanceArraySensors[]);
int Count_consecutive_Zeros(int pos);

//stores in an array the distance reading from each given sensor

uint16_t distanceArray[array_length];

//an array which stores each ADC raw reading, in order to be analyzed

uint16_t adcValArray[Nr_sensors];

//a matrix which will store repeated measurements
//based on a certain number of measurements we can calculate the deviation and the mean

uint16_t MeasurementMatrix[Nr_sensors][Nr_Measurements];

//filters the values of the readings
//is meant to remove the parasitic voltage readings

void Value_Filtering(uint16_t DistanceArraySensors[])
{
	for (int i = 0; i < Nr_sensors; i++)
	{
		uint16_t mean = Mean_Value(i);
		float std_dev = Standard_Deviation(i);
		if (Count_consecutive_Zeros(i) == 0)
			DistanceArraySensors[i] = 0;
		else
		{
			if (std_dev <= (mean * Procent_deviation) / 100)
			{
				DistanceArraySensors[i] = mean + (uint16_t)(std_dev);
			}
			else
			{
				DistanceArraySensors[i] = 0;
			}
		}
	}
}

//based on the ADC reading, and the resolution we are working with;
//calculates the voltage from the reading

uint16_t give_Voltage(uint16_t adcReading)
{
	return ((adcReading * (uint16_t)ADC_REF) / (uint16_t)ADC_RESOLUTION);
}

//calls the distance approximation function and returns a distance, based on a voltage

uint16_t give_Distance(uint16_t voltage)
{
	return(aproxDistance(voltage));
}

//based on our known formula: 10939.7 * x ^ (-0.95), for every given voltage, we have a predefined distance

void configure_Voltage(uint16_t adcValArray[], uint16_t VoltageArray[])
{
	for(int i = 0; i < Nr_sensors; i++)
		 VoltageArray[i] = give_Voltage(adcValArray[i]);
}

//creates the DistanceArray using filtering, comparison and measurement theory

void configure_Distance(ADC_HandleTypeDef hadc1, uint16_t adcValArray[], uint16_t DistanceArraySensors[], uint16_t VoltageArray[])
{
	int i, j;

	for (j = 0; j < Nr_Measurements; j++)
	{
		HAL_ADC_Start_DMA(&hadc1, (uint32_t *)adcValArray, Nr_sensors);
		for (i = 0; i < Nr_sensors ;i++)
		{
			configure_Voltage(adcValArray, VoltageArray);
			MeasurementMatrix[i][j] = give_Distance(VoltageArray[i]);
		}
		HAL_ADC_Stop_DMA(&hadc1);
	}
	Value_Filtering(DistanceArraySensors);
}

//call this function and the readings from all the sensors will be stored in the second parameter given

void Distance_from_all_sensors(ADC_HandleTypeDef hadc1, uint16_t DistanceArraySensors[])
{
	uint16_t VoltageArray[Nr_sensors];

	configure_Distance(hadc1, adcValArray, DistanceArraySensors, VoltageArray);
}

//calculates the average value, given the number of measurements, and their sum

uint16_t Mean_Value(int pos)
{
	uint16_t mean = 0;
	int j;
	for (j = 0; j < Nr_Measurements; j++)
	{
		mean = mean + MeasurementMatrix[pos][j];
	}
	mean = (uint16_t)(mean / Nr_Measurements);
	return (mean);
}

//calculates the normal standard deviation, in order to filter out parasitic voltages
//these voltages may give 0 readings, at distances ranging from 0 to 4 cm

float Standard_Deviation(int pos)
{
	float std_dev = 0;
	float aux = 0;
	uint16_t mean;

	mean = Mean_Value(pos);
	for (int j = 0; j < Nr_Measurements; j++)
	{
		aux = abs(((float)mean - MeasurementMatrix[pos][j]));
		std_dev = std_dev + aux * aux;
	}
	std_dev = std_dev / (float)(Nr_Measurements - 1);
	std_dev = sqrt(std_dev);
	return (std_dev);
}

//init DistanceArray with an increment of 0.1 cm
//for each element in the DistanceArray there is a corresponding element in the VoltageArray

void init_distanceArray(void)
{
	int i=0;
	int j = 400;
	while(j<=3000)
	{
		distanceArray[i] = j;
		j = j + 10;
		i++;
	}
}

//returns an approximated distance
//finds the interval where a voltage reading is situated
//makes the approximation with the least error

uint16_t aproxDistance(uint16_t volt)
{
	uint16_t i = 0;
	while (i < array_length-1)
	{
		if ((volt <= (voltageArray[i])) && (volt >= (voltageArray[i+1])))
		{
			int aux1 = volt - (voltageArray[i]);
			int aux2 = (voltageArray[i+1]) - volt;
			if (aux1 > aux2)
				return (distanceArray[i]);
			else
				return (distanceArray[i+1]);
		}
		i++;
	}
	return (0);
}

//returns the high end value of a current state

int High_Val(int n)
{

	return (Low_Dist + (n) * Step_Size);
}

//returns the low end value of a current state

int Low_Val(int n)
{
	return (Low_Dist + (n - 1) * Step_Size);
}

//given a voltage it returns the state attributed to that voltage (1 to 8)
//states are configured, knowing how many LED's we want to turn on at every given distance

int Give_State(uint16_t n)
{
	int i = 0;
	uint16_t aux = n;

	if (aux == 0)
		return (0);
	while (aux > Low_Dist)
	{
		aux = aux - Step_Size;
		i++;
	}
	if (i > Max_State)
		return (i = Max_State);
	return (i);
}

//the state array will be initialised with 0 => all LED's will be turned on at the beginning

void init_StateArray(uint16_t StateArray[])
{
	for (int i = 0; i < Nr_sensors; i++)
	{
		StateArray[i] = 0;
	}
}

//configures the state array, knowing what readings the sensors have given
//the general purpose of this function is to eliminate the LED flickering
//the flickering occurred when the sensor would read a value very close to a neighboring state
//example: state1-High:600; state2-Low:600
//the function regulates the state change, via a state threshold
//only when we know for sure that the sensors detect a certain state, the switch is made

void State_config(uint16_t StateArray[], uint16_t DistanceArraySensors[])
{
	int i;
	int state;

	for (i = 0; i < Nr_sensors; i++)
	{
		if (StateArray[i] == 0)
		{
			StateArray[i] = Give_State(DistanceArraySensors[i]);
		}
		else
		{
			state = Give_State(DistanceArraySensors[i]);

			if (state == 0)
				StateArray[i] = 0;
			if (state != StateArray[i] && state != 0)
			{
				if (state > StateArray[i])
				{
					if(DistanceArraySensors[i] > (uint16_t)(High_Val(StateArray[i]) + State_Threshold))
					{
						StateArray[i] = state;
					}
				}
				else
				{
					if(DistanceArraySensors[i] < (uint16_t)(Low_Val(StateArray[i]) - State_Threshold))
					{
						StateArray[i] = state;
					}
				}
			}
		}
	}
}

int Count_consecutive_Zeros(int pos)
{
	int count = 0;
	int ok = 0;

	for(int j = 0; j < Nr_Measurements; j++)
	{
		if (MeasurementMatrix[pos][j] == 0)
		{
			count++;
			if (MeasurementMatrix[pos][j+1] == 0 && j < Nr_Measurements)
				ok = 1;
			else
				ok = 0;
		}
		if (count == Consecutive_Zeros)
			return (0);
		if (ok == 0)
			count = 0;
	}
	return (1);
}

