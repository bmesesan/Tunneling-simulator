/*
 * SwcDisplay.c
 *
 *  Created on: Jul 12, 2018
 *      Author: F16438C
 */
#include "main.h"
#include "stm32f4xx_hal.h"
#include "Display.h"
#include "math.h"

void write_to_SLAVE_1(uint8_t addr, uint8_t data, SPI_HandleTypeDef hspi1);
void write_to_SLAVE_2(uint8_t addr, uint8_t data, SPI_HandleTypeDef hspi1);
void init_leds_1(SPI_HandleTypeDef hspi1);
void init_leds_2(SPI_HandleTypeDef hspi1);
void Tunneling(uint16_t DistanceArraySensors[]);
void WeatherGlare_PLUS_Tunneling(uint16_t StateArray[]);
void SignTunneling(uint16_t StateArray[]);
void init_DisplaySettings(SPI_HandleTypeDef hspi1);
void Display(SPI_HandleTypeDef hspi1);
int fPowerSum(int n);
int WeatherGlare_PowerSum( int n);
void AssignVal(int lmin, int lmax, uLedsData *arr, uint8_t val );
void ManualControl(uint8_t Val);

extern uLedsData ledData[16];

SPI_HandleTypeDef hspi1;

void init_led_struct()
{
	AssignVal(0,15,ledData,FullValue);
}

void Tunneling(uint16_t StateArray[])
{
	uint8_t i;
	int aux=3;
	uint8_t value;
	for(i=0;i<=3;i++)
	{
		int length = StateArray[i];
		if (length!=0)
			{
			value = (uint8_t)fPowerSum(length);
			AssignVal(aux*4,aux*4+3,ledData,value);
			}
		else
			AssignVal(aux*4,aux*4+3,ledData,FullValue);
	aux--;
	}
}

void ManualControl(uint8_t Val)
{
	uint8_t i;

	for (i=0;i<=15;i++)
	{
		if(i==(15-Val))
			ledData[i].row = ManualLedsValue;
		else
			ledData[i].row = InitialLedsValue;
	}
}

int fPowerSum(int n)  // {1,2,3,4,5}
{
	uint8_t s=0;
		if (n == 1)
			return 0;
		else
		{
		for (int i = (5 - n) ; i < (3 + n) ; i++)
			s=s+pow(2,i);
		}
		return s;
}

void SignTunneling(uint16_t StateArray[])
{
	uint8_t i;
	int aux=3;
	uint8_t value;
	for(i=0;i<=3;i++)
	{
		int length = StateArray[i];
		if (length!=0)
			{
			AssignVal(aux*4,aux*4+3,ledData,SignValue);
			}
		else
			AssignVal(aux*4,aux*4+3,ledData,FullValue);
	aux--;
	}
}


void init_DisplaySettings(SPI_HandleTypeDef hspi1)
{
	  init_leds_1(hspi1);
	  init_leds_2(hspi1);

	  write_to_SLAVE_1(Intensity_Register,InitialIntensity,hspi1);		//intensity
	  write_to_SLAVE_2(Intensity_Register,InitialIntensity,hspi1);

	  write_to_SLAVE_1(ShutDownMode_Register,ShutDownMode,hspi1);		//shutdown mode normal
	  write_to_SLAVE_2(ShutDownMode_Register,ShutDownMode,hspi1);

	  write_to_SLAVE_1(ScanLimit_Register,ScanLimit,hspi1);		//scan limit
	  write_to_SLAVE_2(ScanLimit_Register,ScanLimit,hspi1);
}


void BendLightLeft(SPI_HandleTypeDef hspi1)
{
	write_to_SLAVE_2(Intensity_Register,BendIntensity,hspi1);
}


void BendLightRight(SPI_HandleTypeDef hspi1)
{
	write_to_SLAVE_1(Intensity_Register,BendIntensity,hspi1);
}

void StraightRoad(SPI_HandleTypeDef hspi1)
{
	write_to_SLAVE_1(Intensity_Register,InitialIntensity,hspi1);
	write_to_SLAVE_2(Intensity_Register,InitialIntensity,hspi1);
}

void WeatherGlare_PLUS_Tunneling(uint16_t StateArray[])
{
	uint8_t i;
	uint8_t value;

	AssignVal(0,4,ledData,WeatherValue);
	AssignVal(11,15,ledData,WeatherValue);

	for(i=0;i<=3;i++)
	{
		int length = StateArray[i];
		switch(i)
		{
		case 0:
			if (length!=0)
			{
				value=(uint8_t)fPowerSum(length);
				AssignVal(13,15,ledData,value);
			}
			else
				AssignVal(13,15,ledData,FullValue);
			break;
		case 1:
			if (length!=0)
			{
				value=(uint8_t)WeatherGlare_PowerSum(length);
				AssignVal(8,12,ledData,value);
			}
			else
				AssignVal(8,12,ledData,WeatherValue);
			break;
		case 2:
			if (length!=0)
			{
				value=(uint8_t)WeatherGlare_PowerSum(length);
				AssignVal(3,7,ledData,value);
			}
			else
				AssignVal(3,7,ledData,WeatherValue);
			break;
		case 3:
			if (length!=0)
			{
				value=(uint8_t)fPowerSum(length);
				AssignVal(0,2,ledData,value);
			}
			else
				AssignVal(0,2,ledData,FullValue);

			break;
		}
	}
}

void AssignVal(int lmin, int lmax, uLedsData *arr, uint8_t val )
{
	for (int j = lmin; j <= lmax; j++)
	{
		arr[j].row=val;
	}
}
void Dim(SPI_HandleTypeDef hspi1)
{
	write_to_SLAVE_1(Intensity_Register,LowBeamIntensity,hspi1);
	write_to_SLAVE_2(Intensity_Register,LowBeamIntensity,hspi1);
}

int WeatherGlare_PowerSum( int n )
{
	uint8_t s=0;
	for (int i = 3 ; i < (2 + n) ; i++)
		s=s+pow(2,i);
	return s;
}

void init_leds_1(SPI_HandleTypeDef hspi1) //initializeaza ledurile la slave1
{
	for (int i=1; i<=8; i++)
		write_to_SLAVE_1(i, InitialLedsValue, hspi1);
}

void init_leds_2(SPI_HandleTypeDef hspi1)	//initializeaza ledurile la slave2
{
	for (int i=1; i<=8; i++)
		write_to_SLAVE_2(i, InitialLedsValue, hspi1);
}


void write_to_SLAVE_1(uint8_t addr, uint8_t data, SPI_HandleTypeDef hspi1)	//scriere spre SLAVE1
{
    uint16_t Addr, Data, Data_to_send;
    Addr = (uint16_t)addr;
    Data = (uint16_t)data;
    Data_to_send = ( (Addr<<8 ) & 0xFF00 ) | Data ;
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, (uint8_t*)&Data_to_send, 1U, 1000U);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET);
}

void write_to_SLAVE_2(uint8_t addr, uint8_t data, SPI_HandleTypeDef hspi1)	//scriere spre SLAVE2
{
     uint16_t Addr, Data, Data_to_send;
     Addr = (uint16_t)addr;
     Data = (uint16_t)data;
     Data_to_send = ( (Addr<<8 ) & 0xFF00 ) | Data ;
     HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
     HAL_SPI_Transmit(&hspi1, (uint8_t*)&Data_to_send, 1U, 1000U);
     HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
}

void Display(SPI_HandleTypeDef hspi1)		//afiseaza
{
	 for(uint8_t i = 1; i <= 16; i++)
	  {
		  if(i<=8)
			  write_to_SLAVE_1(i, ledData[i-1].row ,hspi1);
		  else
			  write_to_SLAVE_2(i-8, ledData[i-1].row ,hspi1);
	  }

}
