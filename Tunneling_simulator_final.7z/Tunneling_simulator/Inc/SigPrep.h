/*
 * SigPrep.h
 *
 *  Created on: Jul 12, 2018
 *      Author: F16438C
 */

#ifndef SWC_SIGPREP_SIGPREP_H_
#define SWC_SIGPREP_SIGPREP_H_

//signals
#define SIGN_DET 0x100
#define WET_DET 0x200
#define BEAM_DET 0x300
#define TUNN_SWITCH 0x400
#define TRACK_BAR 0x500
#define BEND_LIGHT 0x600
#define TRUE 1
#define FALSE 0

typedef enum
{
	LEFT=0,
	STRAIGHT,
	RIGHT,
	OFF
}eTurnStatus;

typedef struct
{
	uint16_t ID;
	uint16_t Data;
} CAN_Info;

typedef struct
{
	_Bool bSignDetect;
	_Bool bWeatherGlare;
	_Bool bBeamStatus;
	_Bool bAutoStatus;
	uint8_t u8TurnStatus;
	uint8_t u8TrackBar;

}System_CANStatus;



#endif /* SWC_SIGPREP_SIGPREP_H_ */
