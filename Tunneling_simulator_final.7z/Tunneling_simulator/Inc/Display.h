/*
 * SwcDisplay.h
 *
 *  Created on: Jul 12, 2018
 *      Author: F16438C
 */

#ifndef SWC_DISPLAY_DISPLAY_H_
#define SWC_DISPLAY_DISPLAY_H_

#define BendIntensity 			0x03
#define InitialIntensity 		0x0C
#define ShutDownMode 			0x01
#define ScanLimit 				0x07
#define InitialLedsValue 		0xFF
#define LowBeamIntensity 		0x03
#define Intensity_Register 		0x0A
#define ShutDownMode_Register 	0x0C
#define ScanLimit_Register 		0x0B
#define FullValue 				0xFF
#define WeatherValue 			0xF8

typedef struct {

	uint8_t led[8];

}tsLeds;

typedef union {
	tsLeds bit;
	uint8_t row;
}uLedsData;

uLedsData ledData[16];

#endif /* SWC_DISPLAY_DISPLAY_H_ */
